import os
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
#from sklearn.metrics import silhouette_score
# from sklearn.manifold import TSNE
import nltk
import warnings
warnings.filterwarnings("ignore")  
import pickle
# from .config import list_products_encoding
# nltk.download('punkt')
# nltk.download('averaged_perceptron_tagger')

is_noun = lambda pos: pos[:2] == 'NN'

def keywords_inventory(dataframe, colonne = 'Description'):
    stemmer = nltk.stem.SnowballStemmer("english")
    keywords_roots  = dict()  # collect the words / root
    keywords_select = dict()  # association: root <-> keyword
    category_keys   = []
    count_keywords  = dict()
    icount = 0
    for s in dataframe[colonne]:
        if pd.isnull(s): continue
        lines = s.lower()
        tokenized = nltk.word_tokenize(lines)
        nouns = [word for (word, pos) in nltk.tag.pos_tag(tokenized) if is_noun(pos)] 
        
        for t in nouns:
            t = t.lower() ; racine = stemmer.stem(t)
            if racine in keywords_roots:                
                keywords_roots[racine].add(t)
                count_keywords[racine] += 1                
            else:
                keywords_roots[racine] = {t}
                count_keywords[racine] = 1
    
    for s in keywords_roots.keys():
        if len(keywords_roots[s]) > 1:  
            min_length = 1000
            for k in keywords_roots[s]:
                if len(k) < min_length:
                    clef = k ; min_length = len(k)            
            category_keys.append(clef)
            keywords_select[s] = clef
        else:
            category_keys.append(list(keywords_roots[s])[0])
            keywords_select[s] = list(keywords_roots[s])[0]
                   
   # print("Nb of keywords in variable '{}': {}".format(colonne,len(category_keys)))
    return category_keys, keywords_roots, keywords_select, count_keywords

def order_cluster(cluster_field_name, target_field_name,df,ascending):
    df_new = df.groupby(cluster_field_name)[target_field_name].mean().reset_index()
    df_new = df_new.sort_values(by=target_field_name,ascending=ascending).reset_index(drop=True)
    df_new['index'] = df_new.index
    df_final = pd.merge(df,df_new[[cluster_field_name,'index']], on=cluster_field_name)
    df_final = df_final.drop([cluster_field_name],axis=1)
    df_final = df_final.rename(columns={"index":cluster_field_name})
    return df_final

def load_data():
    data = pd.read_csv(r"C:\Users\ankita.a\customer_segmentation\myapp\OnlineRetail.csv",encoding = "ISO-8859-1")
    # data1=data.copy()
    data=data.loc[~data["CustomerID"].isna(),:]
    # data=data.loc[data["UnitPrice"]<146,]
    data=data.loc[~(data["UnitPrice"]==0),:]
    
    ##ECOMMERCE ANALYSIS
    print("data read done.....")
    Cust_stat=pd.DataFrame(data["CustomerID"].unique(),columns=["CustomerID"])
    return Cust_stat,data



def get_cutomer_data(Customer_data,df):
    data=df.copy()
    Cust_stat=Customer_data.copy()
    #Total transactions#
    trans=data.groupby("CustomerID")["InvoiceNo"].nunique().reset_index()
    trans.columns=["CustomerID","transactions"]    
    Cust_stat=pd.merge(Cust_stat,trans,on="CustomerID",how="left")
    
    #Return#
    ret=(data.loc[(data.StockCode.str.contains("C"))&(data.Description!="Discount"),:])
    ret=ret.groupby("CustomerID")["InvoiceNo"].nunique().reset_index()
    ret.columns=["CustomerID","return"]
    Cust_stat=pd.merge(Cust_stat,ret,on="CustomerID",how="left")
    Cust_stat=Cust_stat.fillna(0)
    
    # Returned amount
    retamo=(data.loc[(data.StockCode.str.contains("C"))&(data.Description!="Discount"),:])
    retamo["returnPrice"] = abs(retamo["Quantity"] * retamo["UnitPrice"])
    retamount=retamo.groupby("CustomerID")["returnPrice"].sum().reset_index()
    Cust_stat=pd.merge(Cust_stat,retamount,on="CustomerID",how="left")
    Cust_stat["returnPrice"]=Cust_stat["returnPrice"].fillna(0)
    
    # Units per transaction (median) #
    upt_temp=data.loc[~(data.StockCode.str.contains("C")),:]
    upt_temp=upt_temp.groupby(["CustomerID","InvoiceNo"])["Quantity"].sum().reset_index()   
    upt= upt_temp.groupby("CustomerID")["Quantity"].median().reset_index()
    upt.columns=["CustomerID","unitPT"]
    Cust_stat=pd.merge(Cust_stat,upt,on="CustomerID",how="left")
    Cust_stat["unitPT"]=Cust_stat["unitPT"].fillna(0)
    
    # Items per transaction (median)
    ipt_temp=data.loc[~(data.StockCode.str.contains("C")),:]
    ipt_temp=ipt_temp.groupby(["CustomerID","InvoiceNo"])["StockCode"].count().reset_index()
    ipt_temp=ipt_temp[["CustomerID","StockCode"]]
    ipt=ipt_temp.groupby("CustomerID")["StockCode"].median().reset_index().rename(columns={"CustomerID":"CustomerID","StockCode":"itemPT"})
    Cust_stat=pd.merge(Cust_stat,ipt,on="CustomerID",how="left")
    # print(Cust_stat.shape)
    # print(Cust_stat.columns)
    # Time Interval(day): #
    data["date"] = pd.to_datetime(data["InvoiceDate"])
    TI = data.loc[~(data.StockCode.str.contains("C")),:]
    TI = TI[["CustomerID","InvoiceNo","InvoiceDate","date"]]
    TI=TI.drop_duplicates()
    TI["InvoiceHour"] = TI["date"].dt.hour
    TI["InvoiceMon"] = TI["date"].dt.month
    TI["InvoiceWeekDays"] = TI["date"].dt.day_name()
    
    conditions=[(TI["InvoiceMon"]>0) &(TI["InvoiceMon"]<=3),
            (TI["InvoiceMon"]>3) &(TI["InvoiceMon"]<=6),
            (TI["InvoiceMon"]>6) & (TI["InvoiceMon"]<=9),
            (TI["InvoiceMon"]>9) & (TI["InvoiceMon"]<=12)]
    values = ["spring","summer","autumn","winter"]      
    TI["InvoiceSeason"]= np.select(conditions,values)
    
    conditions1=[(TI["InvoiceHour"]>0) &(TI["InvoiceHour"]<=10),
            (TI["InvoiceHour"]>10) &(TI["InvoiceHour"]<=13),
            (TI["InvoiceHour"]>13) & (TI["InvoiceHour"]<=16),
            (TI["InvoiceHour"]>16) & (TI["InvoiceHour"]<=max(TI["InvoiceHour"]))]
    values1 = ["morning","noon","afternoon","night"]
    TI["InvoicePeriod"]= np.select(conditions1,values1)
    
    period_stat = TI[["CustomerID","InvoicePeriod"]].pivot_table(index=['CustomerID'], columns=['InvoicePeriod'], aggfunc=len).fillna(0).reset_index()
    season_stat = TI[["CustomerID","InvoiceSeason"]].pivot_table(index=['CustomerID'], columns=['InvoiceSeason'], aggfunc=len).fillna(0).reset_index()
    weekday_stat = TI[["CustomerID","InvoiceWeekDays"]].pivot_table(index=['CustomerID'], columns=['InvoiceWeekDays'], aggfunc=len).fillna(0).reset_index()
    
    tx_day_order = TI[['CustomerID','date']]
    tx_day_order['InvoiceDay'] = TI['date'].dt.date
    tx_day_order = tx_day_order.drop_duplicates(subset=['CustomerID','InvoiceDay'],keep='first')
    tx_day_order['PrevInvoiceDate'] = tx_day_order.groupby('CustomerID')['InvoiceDay'].shift(1)
    
    tx_day_order['InvoiceDay']=pd.to_datetime(tx_day_order['InvoiceDay'],errors='coerce')

    tx_day_order['PrevInvoiceDate']=pd.to_datetime(tx_day_order['PrevInvoiceDate'],errors='coerce')
    
    
    tx_day_order['DayDiff'] = tx_day_order['InvoiceDay'] - tx_day_order['PrevInvoiceDate']
    tx_day_order['DayDiff']=tx_day_order['DayDiff'].dt.days
    
    tx_day_diff = round(tx_day_order.groupby('CustomerID').agg({'DayDiff': ['mean']}).reset_index().fillna(0),2)
    tx_day_diff.columns = ['CustomerID', 'ave.interval']
    
    Cust_stat=pd.merge(Cust_stat,tx_day_diff,on="CustomerID",how="left")
    Cust_stat=pd.merge(Cust_stat,period_stat,on="CustomerID",how="left")
    Cust_stat=pd.merge(Cust_stat,season_stat,on="CustomerID",how="left")
    Cust_stat=pd.merge(Cust_stat,weekday_stat,on="CustomerID",how="left")
    
    #Total Spending
    data["ttlspend"] = data["Quantity"]*data["UnitPrice"]
    ttl=data.groupby("CustomerID")["ttlspend"].sum().reset_index()
    Cust_stat=pd.merge(Cust_stat,ttl,on="CustomerID",how="left")
    
    # Average Spending
    Cust_stat["aveSpend"]=round(Cust_stat.ttlspend/Cust_stat.transactions,4)
    
    #Average Unit Price
    aveUP=data.loc[~(data.StockCode.str.contains("C")),:]
    aveUP =  aveUP.groupby("CustomerID")["UnitPrice"].median().reset_index()
    Cust_stat=pd.merge(Cust_stat,aveUP,on="CustomerID",how="left")
    
    # returned amount/total spending #
    Cust_stat["retAmount"]=round(Cust_stat.returnPrice/Cust_stat.ttlspend,4)
    
    Cust_stat.to_csv('Customer_data.csv',index=False)
    
    return Cust_stat,data


#DESCRIPTION MATRIX
def get_product_data(df):
    data1=df.copy()
    df_initial = data1.copy()
    df_initial['InvoiceDate'] = pd.to_datetime(df_initial['InvoiceDate'])
    df_initial.dropna(axis = 0, subset = ['CustomerID'], inplace = True)
    df_initial.drop_duplicates(inplace = True)
    
    df_produits = pd.DataFrame(df_initial['Description'].unique()).rename(columns = {0:'Description'})
    keywords, keywords_roots, keywords_select, count_keywords = keywords_inventory(df_produits)
    
    list_products = []
    for k,v in count_keywords.items():
        list_products.append([keywords_select[k],v])
    list_products.sort(key = lambda x:x[1], reverse = True)
    
    ## Remove colors
    list_products = []
    for k,v in count_keywords.items():
        word = keywords_select[k]
        if word in ['pink', 'blue', 'tag', 'green', 'orange']: continue
        if len(word) < 3 or v < 13: continue
        if ('+' in word) or ('/' in word): continue
        list_products.append([word, v])
    #______________________________________________________    
    list_products.sort(key = lambda x:x[1], reverse = True)
    print('total number of tokens:', len(list_products))
    
    ## Description Encoding
    descriptions = df_initial['Description'].unique()
    X = pd.DataFrame()
    for key, occurence in list_products:        
        X.loc[:, key] = list(map(lambda x:int(key.upper() in x), descriptions))
    X.insert(loc=0, column='Description', value=descriptions)
    
    ### PRODUCT DESCRIPTION CLUSTERING AND ITS RELATED FEATURES ###
    d=X.copy()
    d = d.loc[d["Description"].isin(data1["Description"]),]
    d.to_csv("Products.csv",index=False)
    
    product_data=d.copy()
    return product_data




# get statistics by Description
def get_desc_stats(df,product_data):
    data=df.copy()
    # print(product_data)
    d=product_data.copy()
    desc_stat = data.groupby("Description")["UnitPrice"].mean().reset_index().rename(columns={"Description":"Description","UnitPrice":"price_level"})
    
    #Binning the price of each product into different levels
    desc_stat["price_level"]=(pd.cut(desc_stat["price_level"],bins=[0,1,1.5,2,3,5,8,np.inf],labels=[1,2,3,4,5,6,7]))
    desc_stat["price_level"] = 'PL' + desc_stat["price_level"].astype(str)
    desc_stat = desc_stat.pivot_table(index=['Description'], columns=['price_level'], aggfunc=len).fillna(0).reset_index()
    d=pd.merge(d,desc_stat,on="Description")
    
    desc_stat = data.groupby("Description")["Quantity"].median().reset_index().rename(columns={"Description":"Description","Quantity":"quantity_level"})
    desc_stat["quantity_level"]=(pd.cut(desc_stat["quantity_level"],bins=[-np.inf,1,3,5,7,9,15,np.inf],labels=[1,2,3,4,5,6,7]))
    desc_stat["quantity_level"] = 'QL' + desc_stat["quantity_level"].astype(str)
    desc_stat = desc_stat.pivot_table(index=['Description'], columns=['quantity_level'], aggfunc=len).fillna(0).reset_index()
    d=pd.merge(d,desc_stat,on="Description")
    product_stats_data=d.copy()
    return product_stats_data


    


# defining the kmeans function with initialization as k-means++
#Clustering the products keyword data along with the quantity and price level data

def kmeans_model(product_stats_data):
    d = product_stats_data.copy()
    kmeans_cluster = KMeans(n_clusters=8, init='k-means++')
    kmeans_cluster.fit(d.iloc[:,1:])
    
    with open('Kmeans_model','wb') as f:
                Kmeans_model={'model':kmeans_cluster}
                pickle.dump(Kmeans_model, f)
    


def get_clusters_prediction(product_stats_data):
    d=product_stats_data.copy()
    f=open('Kmeans_model','rb')
    kmeans_cluster=pickle.load(f)['model']
    print(product_stats_data.columns[-15:])
    d["cluster"] = kmeans_cluster.predict(d.iloc[:,1:])
    cluster_pred=d.copy()
    

    d.to_csv("Products_with_PriceQuantity.csv",index=False)
    
    return cluster_pred
    
    
def data_desc_cluster(cluster_pred,df,Customer_data):
    data=df.copy()
    desc=cluster_pred.copy()
    Cust_stat=Customer_data.copy()
    # append description's cluster to data #
    df2=desc[["Description","cluster"]]
    data = data.merge(df2,how="left",on="Description")
    # print(df.columns)
    # calculate a customer spend how much on products of each cluster #
    tmp=data.groupby(["CustomerID","cluster"])["ttlspend"].sum().reset_index()    
    cluster_spend_stat = tmp.pivot_table(index=['CustomerID'], columns=['cluster'],values=["ttlspend"]).fillna(0).reset_index().set_index("CustomerID")
    cluster_spend_stat.columns = cluster_spend_stat.columns.droplevel(0)
    cluster_spend_stat = cluster_spend_stat.rename_axis(None, axis=1)
    cluster_spend_stat=cluster_spend_stat.add_prefix("ttlspend_cluster").reset_index()
    Cust_stat=pd.merge(Cust_stat,cluster_spend_stat,on="CustomerID",how="left")    
    Cust_stat= Cust_stat.fillna(0)
  
    return Cust_stat 
#TSNE for reductionalilty
    
def reduc_data(Customer_data):
    Cust_stat=Customer_data.copy()
    from sklearn.manifold import TSNE

    tsnefunc=TSNE()
    tsne=tsnefunc.fit_transform(Cust_stat.iloc[:,1:])
    with open('TSNE','wb') as f:
                TSNE={'model':tsnefunc}
                pickle.dump(TSNE, f)
    
    reduced_data=tsne
    reduced_data1=pd.DataFrame(tsne,columns=['col1','col2'])
    reduced_data1['CustomerID']=Cust_stat['CustomerID'].unique()
    reduced_data1.to_csv("reduced_data.csv",index=False)
    Cust_stat.to_csv('Customer_detail.csv',index=False)
    return reduced_data,Cust_stat

def reduc_data_test(x):
    tsne=pd.read_csv(r"C:\Users\ankita.a\customer_segmentation\reduced_data.csv")
    tsne=tsne[tsne['CustomerID']==x].loc[:,tsne.columns!='CustomerID']
    reduced_data=tsne.to_numpy()
    print(reduced_data)

    return reduced_data
    
def reduced_cluster(reduced_data):
    tsne=reduced_data.copy()
    #Saving tsne model
    
    
    #Clustering/Segmenting TSNE data
    kmeans_cluster1= KMeans(n_clusters=4)
    kmeans_cluster1.fit(tsne)
    
    #Saving cluster model
    with open('Kmeans_model1','wb') as f:
                Kmeans_model1={'model':kmeans_cluster1}
                pickle.dump(Kmeans_model1, f)

def get_final_cluster_prediction(reduced_data,Customer_data):    
    Cust_stat= Customer_data.copy()
    f=open('Kmeans_model1','rb')
    kmeans_cluster1=pickle.load(f)['model']
    Cust_stat["Res_cluster"] = kmeans_cluster1.predict(reduced_data)
    #Overall Final results
    Cust_stat.to_csv("Final_Segmentation_results1.csv",index=False)
    
    final_data=Cust_stat.copy()
    return final_data


def get_final_cluster_prediction_test(reduced_data):    
    f=open('Kmeans_model1','rb')
    kmeans_cluster1=pickle.load(f)['model']
    Res_cluster = kmeans_cluster1.predict(reduced_data)[0]
    #Overall Final results 
    # final_data=Cust_stat.copy()
    return Res_cluster
    
    
    
