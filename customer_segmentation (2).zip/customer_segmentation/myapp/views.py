from django.shortcuts import render
import warnings
warnings.filterwarnings('ignore')
# Create your views here.
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 29 13:02:47 2021

@author: ankita.a
"""
from myapp.seg_code import load_data,get_final_cluster_prediction_test,get_cutomer_data,reduc_data_test, get_product_data,get_desc_stats,kmeans_model,get_clusters_prediction,data_desc_cluster,reduc_data,reduced_cluster,get_final_cluster_prediction
from django.http import JsonResponse
# import time

def model_training(request):
    Customer_data,df=load_data()
    Customer_data,df=get_cutomer_data(Customer_data,df)
    product_data=get_product_data(df)
    product_stats_data=get_desc_stats(df,product_data)
    kmeans_model(product_stats_data)
    cluster_pred=get_clusters_prediction(product_stats_data)
    Customer_data=data_desc_cluster(cluster_pred,df,Customer_data)
    reduced_data,Customer_data=reduc_data(Customer_data)
    reduced_cluster(reduced_data)
    final_data=get_final_cluster_prediction(reduced_data,Customer_data)
    print(final_data.shape)
    
    return JsonResponse({'model_training':'completed'})
    
def model_testing(request):
    
    cluster_map={0:"Needs Attention",1:"Loyal Customers or Champions",2:"Potential loyalist",3:"Needs Attention"}
    
    try:
        C_ID=int(request.GET.get('C_ID'))
        reduced_data=reduc_data_test(C_ID)
        Res_cluster=get_final_cluster_prediction_test(reduced_data)
        return JsonResponse({"cluster":str(Res_cluster),"description":cluster_map.get(Res_cluster)})
    except:
        return JsonResponse({"cluster":"invalid customer id"})
    
# model_training()